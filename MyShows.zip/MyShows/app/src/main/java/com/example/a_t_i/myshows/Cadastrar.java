package com.example.a_t_i.myshows;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Cadastrar extends AppCompatActivity {

    private EditText edtEmailCadastro;
    private EditText edtSenhaCadastro;

    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);

        edtEmailCadastro = findViewById(R.id.edtEmailCad);
        edtSenhaCadastro = findViewById(R.id.edtSenhaCad);

        auth = FirebaseAuth.getInstance();

    }

    public void cadastrarUsuario(View view) {

        String email = edtEmailCadastro.getText().toString().trim();
        String senha = edtSenhaCadastro.getText().toString();


        auth.createUserWithEmailAndPassword(email,senha)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Cadastrar.this, "Usuário cadastrado com Sucesso!", Toast.LENGTH_SHORT).show();
                        }else{
                            String resposta = task.getException().toString();
                            Toast.makeText(Cadastrar.this, "Erro ao cadastrar Usuário!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }
}
