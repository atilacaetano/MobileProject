package com.example.a_t_i.myshows;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

public class EventoRepositorio {

    private EventoDao eventoDao;
    private LiveData<List<Evento>> allEventos;

    public EventoRepositorio(Application application){
        EventoDatabase database = EventoDatabase.getInstance(application);
        eventoDao = database.eventoDao();
        allEventos = eventoDao.getAllEvento();
    }

    public void insert(Evento evento){
        new InsertEventoAsyncTask(eventoDao).execute(evento);
    }

    public void update(Evento evento){
        new UpdateEventoAsyncTask(eventoDao).execute(evento);
    }

    public void delete(Evento evento){
        new DeleteEventoAsyncTask(eventoDao).execute(evento);
    }

    public void deleteAllEventos(){
        new DeleteAllEventosEventoAsyncTask(eventoDao).execute();
    }

    public LiveData<List<Evento>> getAllEventos(){
        return allEventos;
    }

    private static class InsertEventoAsyncTask extends AsyncTask<Evento, Void,Void> {

        private EventoDao eventoDao;

        private InsertEventoAsyncTask(EventoDao eventoDao){
            this.eventoDao = eventoDao;
        }

        @Override
        protected Void doInBackground(Evento... eventos) {
            eventoDao.insert(eventos[0]);
            return null;
        }
    }

    private static class UpdateEventoAsyncTask extends AsyncTask<Evento, Void,Void>{

        private EventoDao eventoDao;

        private UpdateEventoAsyncTask(EventoDao eventoDao){
            this.eventoDao = eventoDao;
        }

        @Override
        protected Void doInBackground(Evento... eventos) {
            eventoDao.update(eventos[0]);
            return null;
        }
    }

    private static class DeleteEventoAsyncTask extends AsyncTask<Evento, Void,Void>{

        private EventoDao eventoDao;

        private DeleteEventoAsyncTask(EventoDao eventoDao){
            this.eventoDao = eventoDao;
        }

        @Override
        protected Void doInBackground(Evento... eventos) {
            eventoDao.delete(eventos[0]);
            return null;
        }
    }


    private static class DeleteAllEventosEventoAsyncTask extends AsyncTask<Void, Void,Void>{

        private EventoDao eventoDao;

        private DeleteAllEventosEventoAsyncTask(EventoDao eventoDao){
            this.eventoDao = eventoDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            eventoDao.deleteAllNotes();
            return null;
        }
    }

}
