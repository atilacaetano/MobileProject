package com.example.a_t_i.myshows;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class EventoAdapter extends RecyclerView.Adapter<EventoAdapter.EventoHolder>  {

    private List<Evento> eventos = new ArrayList<>();

    @NonNull
    @Override
    public EventoHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.evento_item,parent,false);
        return new EventoHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull EventoHolder eventoHolder, int i) {
        Evento currentEvento = eventos.get(i);
        eventoHolder.textTitle.setText(currentEvento.getBanda());
        eventoHolder.textLocal.setText(currentEvento.getLocal());

    }

    @Override
    public int getItemCount() {
        return eventos.size();
    }

    public void setEventos(List<Evento> eventos){
        this.eventos = eventos;
        notifyDataSetChanged();
    }

    class EventoHolder extends RecyclerView.ViewHolder{
        private TextView textTitle;
        private TextView textLocal;

        public EventoHolder(View itemView){
            super(itemView);
            textTitle = itemView.findViewById(R.id.text_view_banda);
            textLocal = itemView.findViewById(R.id.text_view_local);
        }
    }

}
