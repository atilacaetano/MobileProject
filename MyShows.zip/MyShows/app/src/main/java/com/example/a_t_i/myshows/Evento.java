package com.example.a_t_i.myshows;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "tabela_evento")
public class Evento {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String banda;
    private String nomeEvento;
    private String local;
    private String descricao;

    public Evento(String banda, String nomeEvento, String local, String descricao) {
        this.banda = banda;
        this.nomeEvento = nomeEvento;
        this.local = local;
        this.descricao = descricao;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getBanda() {
        return banda;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public String getLocal() {
        return local;
    }

    public String getDescricao() {
        return descricao;
    }
}
