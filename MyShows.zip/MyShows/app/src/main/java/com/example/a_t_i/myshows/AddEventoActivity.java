package com.example.a_t_i.myshows;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEventoActivity extends AppCompatActivity {

    public static final String EXTRA_BANDA = "com.example.a_t_i.recycleview_teste.EXTRA_BANDA";
    public static final String EXTRA_EVENTO = "com.example.a_t_i.recycleview_teste.EXTRA_EVENTO";
    public static final String EXTRA_LOCAL = "com.example.a_t_i.recycleview_teste.EXTRA_LOCAL";
    public static final String EXTRA_DESC = "com.example.a_t_i.recycleview_teste.EXTRA_DESC";


    private EditText edt_banda;
    private EditText edt_evento;
    private EditText edt_local;
    private EditText edt_desc;
    private Button btn_ok;
    private Button btn_cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_evento);

        edt_banda = findViewById(R.id.edt_text_banda);
        edt_evento = findViewById(R.id.edt_text_evento);
        edt_local = findViewById(R.id.edt_text_local);
        edt_desc = findViewById(R.id.edt_text_desc);

        btn_ok = findViewById(R.id.btn_confirmar);
        btn_cancel = findViewById(R.id.btn_cancel);
    }

    private void saveEvento(){
        String banda = edt_banda.getText().toString();
        String evento = edt_evento.getText().toString();
        String local = edt_local.getText().toString();
        String desc = edt_desc.getText().toString();

        if (banda.trim().isEmpty() || evento.trim().isEmpty()|| banda.trim().isEmpty() || evento.trim().isEmpty()){
            Toast.makeText(this, "Insira os dados completos", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent();
        intent.putExtra(EXTRA_BANDA,banda);
        intent.putExtra(EXTRA_EVENTO,evento);
        intent.putExtra(EXTRA_LOCAL,local);
        intent.putExtra(EXTRA_DESC,desc);

        setResult(RESULT_OK,intent);
        finish();
    }

    public void confirmar(View view) {
        if (btn_ok != null){
            saveEvento();
        }
        else {

        }
    }

    public void cancelar(View view) {
        Intent intent = new Intent(AddEventoActivity.this,MainActivity.class);
        startActivity(intent);
    }
}
