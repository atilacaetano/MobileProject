package com.example.a_t_i.myshows;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;

@Database(entities = {Evento.class},version = 1)
public abstract class EventoDatabase extends RoomDatabase {

    private static EventoDatabase instance;

    public abstract EventoDao eventoDao();

    public static synchronized EventoDatabase getInstance(Context context){
        if (instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    EventoDatabase.class,"evento_database")
                    .fallbackToDestructiveMigration().addCallback(roomCallbak).build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallbak = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsynkTask(instance).execute();
        }
    };

    private static class PopulateDbAsynkTask extends AsyncTask<Void,Void,Void> {

        private EventoDao eventoDao;

        private PopulateDbAsynkTask(EventoDatabase db){
            eventoDao = db.eventoDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            eventoDao.insert(new Evento("Caso Serio","bar","ponta negra","3 horas"));
            return null;
        }
    }
}
