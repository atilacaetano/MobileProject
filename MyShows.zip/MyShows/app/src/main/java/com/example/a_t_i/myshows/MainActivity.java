package com.example.a_t_i.myshows;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.List;


public class MainActivity extends AppCompatActivity {

    private EventoView eventoView;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();

        FloatingActionButton btn_add = findViewById(R.id.button_add_evento);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,AddEventoActivity.class);
                startActivityForResult(intent,1);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final EventoAdapter adapter = new EventoAdapter();
        recyclerView.setAdapter(adapter);

        eventoView = ViewModelProviders.of(this).get(EventoView.class);
        eventoView.getAllEventos().observe(this, new Observer<List<Evento>>() {
            @Override
            public void onChanged(@Nullable List<Evento> eventos) {
                adapter.setEventos(eventos);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode==RESULT_OK){
            String banda = data.getStringExtra(AddEventoActivity.EXTRA_BANDA);
            String evento_tipo = data.getStringExtra(AddEventoActivity.EXTRA_EVENTO);
            String local = data.getStringExtra(AddEventoActivity.EXTRA_LOCAL);
            String desc = data.getStringExtra(AddEventoActivity.EXTRA_DESC);

            Evento evento = new Evento(banda,evento_tipo,local,desc);
            eventoView.insert(evento);

            Toast.makeText(this, "Evento salvo", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, "Evento não salvo", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.act_exit) {
            auth.signOut();
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
