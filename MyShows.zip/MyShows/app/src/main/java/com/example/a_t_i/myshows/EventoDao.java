package com.example.a_t_i.myshows;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface EventoDao {
    @Insert
    void insert(Evento evento);

    @Update
    void update(Evento evento);

    @Delete
    void delete(Evento evento);

    @Query("DELETE FROM tabela_evento")
    void deleteAllNotes();

    @Query("SELECT * FROM tabela_evento")
    LiveData<List<Evento>> getAllEvento();

}
