package com.example.a_t_i.myshows;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class EventoView extends AndroidViewModel {

    private EventoRepositorio repository;
    private LiveData<List<Evento>> allEventos;

    public EventoView(@NonNull Application application) {
        super(application);
        repository = new EventoRepositorio(application);
        allEventos = repository.getAllEventos();
    }

    public void insert(Evento evento){

        repository.insert(evento);
    }
    public void update(Evento evento){
        repository.update(evento);
    }
    public void delete(Evento evento){
        repository.delete(evento);
    }
    public void deleteAllEventos(){
        repository.deleteAllEventos();
    }

    public LiveData<List<Evento>> getAllEventos() {
        return allEventos;
    }
}
